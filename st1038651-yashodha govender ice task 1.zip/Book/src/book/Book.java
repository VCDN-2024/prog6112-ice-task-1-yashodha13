/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package book;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class Book {

    // Phase 1: Create an array with five book titles
    static String[] books = {"Harry Potter", "The Great Gatsby", "To Kill a Mockingbird", "Pride and Prejudice", "Othello"};

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Phase 4: Prompt the user whether to sort in ascending or descending order
        System.out.println("Do you want to sort the books in ascending or descending order? (A/D): ");
        char choice = scanner.next().charAt(0);

        if (choice == 'A' || choice == 'a') {
            // Sorting in ascending order
            insertionSortAscending(books);
            System.out.println("Books sorted in ascending order:");
        } else if (choice == 'D' || choice == 'd') {
            // Sorting in descending order
            insertionSortDescending(books);
            System.out.println("Books sorted in descending order:");
        } else {
            System.out.println("Invalid choice. Please enter A or D.");
            return;
        }

        // Display the sorted list of books
        for (String book : books) {
            System.out.println(book);
        }

        scanner.close();
    }

    // Phase 2: Method to sort the array in ascending order using insertion sort
    public static void insertionSortAscending(String[] array) {
        // Loop through each element starting from the second one
        for (int i = 1; i < array.length; i++) {
            String key = array[i]; // The element to be compared and placed in the correct position
            int j = i - 1;

            // Move elements that are greater than 'key' to one position ahead of their current position
            while (j >= 0 && array[j].compareTo(key) > 0) {
                array[j + 1] = array[j]; // Shift larger element to the right
                j = j - 1;
            }
            array[j + 1] = key; // Place 'key' in its correct position
        }
    }

    // Phase 3: Method to sort the array in descending order using insertion sort
    public static void insertionSortDescending(String[] array) {
        // Loop through each element starting from the second one
        for (int i = 1; i < array.length; i++) {
            String key = array[i]; // The element to be compared and placed in the correct position
            int j = i - 1;

            // Move elements that are smaller than 'key' to one position ahead of their current position
            while (j >= 0 && array[j].compareTo(key) < 0) {
                array[j + 1] = array[j]; // Shift smaller element to the right
                j = j - 1;
            }
            array[j + 1] = key; // Place 'key' in its correct position
        }
    }
}
